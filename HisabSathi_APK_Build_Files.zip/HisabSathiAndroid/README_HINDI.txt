HISAB SATHI - ANDROID STUDIO PROJECT

यह HTML ऐप का Android WebView wrapper प्रोजेक्ट है। मूल हिसाब-किताब HTML ऐप assets/index.html में रखा गया है।

Android ऐप बनाने के लिए:
1. कंप्यूटर में Android Studio इंस्टॉल करें।
2. Android Studio में इस ZIP को Extract करके HisabSathiAndroid फोल्डर Open करें।
3. Gradle Sync पूरा होने दें (पहली बार इंटरनेट चाहिए)।
4. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
5. APK app/build/outputs/apk/debug/app-debug.apk में मिलेगी।

मुख्य बातें:
- ऐप Android launcher से खुलेगा।
- WebView में JavaScript, DOM storage और IndexedDB सक्षम हैं।
- फोटो/स्क्रीनशॉट चुनने के लिए Android file chooser जुड़ा है।
- डाउनलोड (Backup आदि) Downloads में सेव होंगे।
- Print/PDF Android print dialog से खुलेगा।
- WhatsApp/बाहरी लिंक Android ऐप/ब्राउज़र में खुलेंगे।

ध्यान दें:
- इस वातावरण में Android SDK/Gradle उपलब्ध नहीं था, इसलिए यहाँ सीधे install होने वाली APK compile नहीं की जा सकी। यह Android Studio में APK बनाने योग्य source project है।
- PDF बनाने वाली मौजूदा HTML सुविधा html2pdf CDN लोड करती है, इसलिए PDF generation के लिए इंटरनेट चाहिए।
- डेटा इसी डिवाइस के ऐप WebView storage में रहता है। फोन बदलने से पहले ऐप के Backup विकल्प से JSON backup जरूर लें।
