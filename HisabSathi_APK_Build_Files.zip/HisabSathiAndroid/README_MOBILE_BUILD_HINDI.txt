HISAB SATHI - MOBILE SE APK BANANE KA RASTA

Is project me GitHub Actions cloud build workflow joda gaya hai. Isse Android Studio/laptop ki zarurat nahi; GitHub ke server APK banayenge.

Zaroori baat:
- GitHub par free account chahiye.
- Project ke andar ki files/folders GitHub repository me upload karni hongi.
- Upload ke baad Actions tab me build chalega. Safal hone par Hisab-Sathi-APK artifact se APK download hogi.

Steps (mobile browser se):
1. ZIP ko phone me download karke extract karein.
2. github.com par sign in karke New repository banayein; naam HisabSathiAndroid rakhein. Public ya Private dono chalega.
3. Repository me project folder HisabSathiAndroid ke ANDAR ki sabhi files/folders upload karein (root me build.gradle, settings.gradle aur app folder dikhna chahiye). .github folder bhi upload hona zaroori hai.
4. Upload/commit ke baad repository ke Actions tab me Build Hisab Sathi APK workflow kholen.
5. Build complete hone par run kholen, Artifacts me Hisab-Sathi-APK download karein.
6. ZIP extract karke app-debug.apk par tap karein. Android pooche to is source se install ki permission dein.

Agar mobile par folder upload mushkil ho, GitHub website me browser ka Desktop site mode try karein.

APK abhi compile nahi hui hai. Cloud build chalne aur successful hone ke baad hi installable APK milegi.
